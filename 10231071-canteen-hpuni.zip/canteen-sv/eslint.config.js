import js from '@eslint/js';
import globals from 'globals';

export default [
  { ignores: ['dist/', 'data/'] },
  js.configs.recommended,
  { files: ['src/**', 'scripts/**', 'test/**', 'eslint.config.js'], languageOptions: { globals: globals.node } },
  { files: ['public/**'], languageOptions: { sourceType: 'script', globals: { ...globals.browser, QRCode: 'readonly' } } },
];
