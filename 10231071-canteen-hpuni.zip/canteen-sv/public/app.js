const $ = (s) => document.querySelector(s);
const esc = (s) => String(s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' })[c]);
const vnd = (n) => Math.round(n).toLocaleString('vi-VN') + 'đ';
const fmt = (t) => new Date(t).toLocaleString('vi-VN', { hour: '2-digit', minute: '2-digit', day: '2-digit', month: '2-digit' });
const p2 = (n) => String(n).padStart(2, '0');
const TABS = {
  admin: [['sell', 'Bán hàng'], ['menu', 'Thực đơn & kho'], ['rep', 'Báo cáo'], ['pw', 'Đổi mật khẩu']],
  cashier: [['sell', 'Bán hàng'], ['pw', 'Đổi mật khẩu']],
  student: [['card', 'Thẻ của tôi'], ['pw', 'Đổi mật khẩu']],
};
const now = new Date();
let token = localStorage.getItem('token'), me = null, tab = '', menu = [], cat = 'Tất cả', cart = {}, pay = 'cash';
let delId = null, card = null, rep = null, month = `${now.getFullYear()}-${p2(now.getMonth() + 1)}`, tt;

async function api(path, method = 'GET', body) {
  const res = await fetch('/api' + path, {
    method,
    headers: { 'Content-Type': 'application/json', ...(token ? { Authorization: 'Bearer ' + token } : {}) },
    body: body ? JSON.stringify(body) : undefined,
  });
  const json = await res.json().catch(() => ({}));
  if (!res.ok) {
    if (res.status === 401 && token) signOut();
    throw new Error(json.error || 'Có lỗi xảy ra');
  }
  return json;
}
function toast(t) {
  const e = $('#toast');
  e.textContent = t;
  e.style.display = 'block';
  clearTimeout(tt);
  tt = setTimeout(() => (e.style.display = 'none'), 2600);
}
function signOut() {
  token = null; me = null; cart = {};
  localStorage.removeItem('token');
  render();
}

async function go(t) {
  tab = t; delId = null;
  try {
    if (t === 'sell' || t === 'menu') menu = await api('/menu');
    if (t === 'card') card = await api('/my/card');
    if (t === 'rep') {
      const today = `${now.getFullYear()}-${p2(now.getMonth() + 1)}-${p2(now.getDate())}`;
      rep = { day: await api('/reports/daily?date=' + today), mon: await api('/reports/monthly?month=' + month) };
    }
  } catch (e) { toast(e.message); }
  render();
}

function loginView() {
  return `<div class="two"><div class="card"><h2>Đăng nhập</h2><div class="row" style="flex-direction:column;align-items:stretch">
    <label>Số điện thoại<input id="lu" type="tel" inputmode="tel" placeholder="0912345678" autocomplete="username"></label>
    <label>Mật khẩu<input id="lp" type="password" autocomplete="current-password"></label>
    <button class="btn" data-act="login">Đăng nhập</button>
    <p class="sm">Quên mật khẩu? Mang thẻ/giấy tờ đến quầy thu ngân để được cấp lại mật khẩu.</p></div></div>
    <div class="card"><h2>Sinh viên đăng ký thẻ mới</h2><div class="row" style="flex-direction:column;align-items:stretch">
    <label>Số điện thoại<input id="rs" type="tel" inputmode="tel" placeholder="0912345678" autocomplete="username"></label><label>Họ tên<input id="rn" autocomplete="name"></label>
    <label>Đặt mật khẩu (tối thiểu 6 ký tự)<input id="rp" type="password" minlength="6" autocomplete="new-password"></label>
    <button class="btn" data-act="register">Đăng ký thẻ</button></div></div></div>`;
}

function sellView() {
  const cats = ['Tất cả', ...new Set(menu.map((m) => m.category))];
  const list = menu.filter((m) => cat === 'Tất cả' || m.category === cat);
  const lines = Object.entries(cart).map(([id, q]) => ({ m: menu.find((x) => x.id === +id), q })).filter((l) => l.m);
  const total = lines.reduce((s, l) => s + l.m.price * l.q, 0);
  return `<div class="sell"><section>
  <div class="chips">${cats.map((c) => `<button class="chip" data-act="cat" data-id="${esc(c)}" aria-pressed="${c === cat}">${esc(c)}</button>`).join('')}</div>
  <div class="grid">${list.map((m) => `<button class="tile" data-act="add" data-id="${m.id}" ${m.stock - (cart[m.id] || 0) <= 0 ? 'disabled' : ''}>
    <b>${esc(m.name)}</b><span class="sm ${m.stock <= 5 ? 'low' : ''}">${m.stock <= 0 ? 'Hết hàng' : 'Còn ' + m.stock}</span><span class="pr">${vnd(m.price)}</span></button>`).join('') ||
    `<p class="empty">Chưa có món nào.${me.role === 'admin' ? ' Thêm món ở tab Thực đơn & kho.' : ' Nhờ quản lý thêm món.'}</p>`}</div>
  <div class="card" style="margin-top:16px"><h2>Nạp tiền vào thẻ</h2><div class="row">
    <label>Mã thẻ<input id="tc" autocomplete="off"></label><label>Số tiền (đ)<input id="ta" type="number" min="1000" step="1000"></label>
    <button class="btn" data-act="topup">Nạp tiền</button></div></div>
  <div class="card" style="margin-top:16px"><h2>Cấp lại mật khẩu cho sinh viên</h2><p class="sm">Chỉ làm sau khi đã xác minh sinh viên trực tiếp tại quầy.</p><div class="row">
    <label>Số điện thoại<input id="rsp" type="tel" inputmode="tel" autocomplete="off"></label><label>Mật khẩu mới<input id="rsw" type="text" autocomplete="off" minlength="6"></label>
    <button class="btn" data-act="resetpw">Cấp lại</button></div></div></section>
  <aside class="card cart"><h2>Đơn hiện tại</h2>
  ${lines.length ? lines.map((l) => `<div class="line"><span class="nm">${esc(l.m.name)}<br><span class="sm">${vnd(l.m.price)}</span></span>
    <span class="qty"><button data-act="dec" data-id="${l.m.id}" aria-label="Giảm">−</button>${l.q}<button data-act="add" data-id="${l.m.id}" aria-label="Tăng">+</button></span></div>`).join('') : '<p class="empty">Chọn món để thêm vào đơn.</p>'}
  <div class="tot"><span>Tổng</span><span>${vnd(total)}</span></div>
  <div class="seg"><button data-act="pay" data-id="cash" aria-pressed="${pay === 'cash'}">Tiền mặt</button><button data-act="pay" data-id="card" aria-pressed="${pay === 'card'}">Thẻ sinh viên</button></div>
  ${pay === 'card' ? '<input id="cm" placeholder="Mã thẻ (dưới mã QR)" autocomplete="off" style="width:100%;margin-bottom:8px"><input id="cp" type="password" placeholder="Mật khẩu do sinh viên nhập" autocomplete="off" style="width:100%;margin-bottom:8px">' : ''}
  <button class="btn full" data-act="checkout">Thanh toán</button>
  ${lines.length ? '<button class="btn ghost" style="margin-top:8px;width:100%" data-act="clear">Xóa đơn</button>' : ''}</aside></div>`;
}

function pwView() {
  return `<div class="card" style="max-width:420px"><h2>Đổi mật khẩu</h2><div class="row" style="flex-direction:column;align-items:stretch">
    <label>Mật khẩu hiện tại<input id="po" type="password" autocomplete="current-password"></label>
    <label>Mật khẩu mới (tối thiểu 6 ký tự)<input id="pn" type="password" autocomplete="new-password"></label>
    <label>Nhập lại mật khẩu mới<input id="pc" type="password" autocomplete="new-password"></label>
    <button class="btn" data-act="chpw">Đổi mật khẩu</button></div></div>`;
}

function menuView() {
  return `<div class="card" style="margin-bottom:16px"><h2>Thêm món mới</h2><div class="row">
  <label>Tên món<input id="nn"></label><label>Nhóm<input id="nc" placeholder="Món chính"></label>
  <label>Giá (đ)<input id="np" type="number" min="1" step="1000"></label><label>Tồn kho<input id="ns" type="number" min="0"></label>
  <button class="btn" data-act="addm">Thêm món</button></div></div>
  <div class="card"><h2>Thực đơn và tồn kho</h2>${menu.length ? `<div class="tw"><table><thead><tr><th>Món</th><th>Nhóm</th><th>Giá (đ)</th><th>Tồn kho</th><th></th></tr></thead><tbody>
  ${menu.map((m) => `<tr><td>${esc(m.name)}</td><td class="sm">${esc(m.category)}</td>
  <td><input type="number" min="1" step="1000" data-chg="price" data-id="${m.id}" value="${m.price}" aria-label="Giá ${esc(m.name)}"></td>
  <td><input type="number" min="0" data-chg="stock" data-id="${m.id}" value="${m.stock}" aria-label="Tồn kho ${esc(m.name)}"></td>
  <td class="n"><button class="btn ghost" data-act="delm" data-id="${m.id}">${delId === m.id ? 'Chắc chắn xóa?' : 'Xóa'}</button></td></tr>`).join('')}</tbody></table></div>` : '<p class="empty">Chưa có món nào.</p>'}</div>`;
}

const statBox = (label, v) => `<div class="card stat"><span class="sm">${label}</span><b>${v}</b></div>`;
const topList = (t, empty) => (t.length ? t.map((x) => `<div class="line"><span class="nm">${esc(x.name)}</span><b>${x.qty}</b></div>`).join('') : `<p class="empty">${empty}</p>`);

function repView() {
  const d = rep.day, m = rep.mon, mx = Math.max(1, ...m.days.map((x) => x.revenue));
  return `<h2>Hôm nay</h2><div class="stats">${statBox('Doanh thu', vnd(d.revenue))}${statBox('Số đơn', d.orders)}${statBox('Tiền mặt', vnd(d.cash))}${statBox('Thẻ sinh viên', vnd(d.card))}</div>
  <div class="card"><div class="row"><label>Báo cáo theo tháng<input type="month" id="rm" data-mon="1" value="${month}"></label></div>
  <div class="stats">${statBox('Doanh thu tháng', vnd(m.revenue))}${statBox('Số đơn', m.orders)}${statBox('Tiền mặt', vnd(m.cash))}${statBox('Thẻ sinh viên', vnd(m.card))}</div>
  <h2>Doanh thu theo ngày</h2><div class="bars" style="gap:2px">${m.days.map((x) => `<div class="bar" title="Ngày ${x.day}: ${vnd(x.revenue)}"><i style="height:${(x.revenue / mx) * 85}%"></i><span class="sm" style="font-size:9px">${x.day}</span></div>`).join('')}</div>
  <h2 style="margin-top:14px">Bán chạy trong tháng</h2>${topList(m.top, 'Chưa có đơn nào trong tháng này.')}</div>`;
}

function cardView() {
  return `<div class="card" style="margin-bottom:16px"><h2>Xin chào, ${esc(card.full_name)}</h2><p class="sm">SĐT ${esc(card.phone)}</p>
  <div id="qr" style="background:#fff;padding:10px;border-radius:10px;display:inline-block"></div>
  <div class="sm">Mã thẻ: <b>${esc(card.card_code)}</b> · đưa mã QR này khi thanh toán</div>
  <div class="stat" style="margin-top:12px"><span class="sm">Số dư thẻ</span><b style="font-size:26px">${vnd(card.balance)}</b></div>
  <p class="sm">Nạp tiền tại quầy thu ngân. Chỉ bạn xem được số dư và lịch sử của thẻ này.</p></div>
  <div class="card"><h2>Lịch sử mua của bạn</h2>${card.orders.length ? `<div class="tw"><table><tbody>${card.orders.map((o) => `<tr><td class="sm">${fmt(o.created_at)}</td><td>${o.items.map((i) => esc(i.name) + ' ×' + i.qty).join(', ')}</td><td class="n"><b>${vnd(o.total)}</b></td></tr>`).join('')}</tbody></table></div>` : '<p class="empty">Bạn chưa mua gì bằng thẻ.</p>'}</div>`;
}

function render() {
  $('#nav').innerHTML = me ? (TABS[me.role] || []).map(([id, l]) => `<button data-act="tab" data-id="${id}" aria-current="${id === tab}">${l}</button>`).join('') + `<button data-act="logout">Đăng xuất (${esc(me.full_name)})</button>` : '';
  $('#app').innerHTML = !me ? loginView() : { sell: sellView, menu: menuView, rep: repView, card: cardView, pw: pwView }[tab]();
  if ($('#qr') && card && window.QRCode) new QRCode($('#qr'), { text: card.card_code, width: 150, height: 150 });
}

async function enter(r) {
  token = r.token; me = r.user;
  localStorage.setItem('token', token);
  await go(TABS[me.role][0][0]);
}
const val = (id) => $('#' + id).value;
const run = (fn) => fn().catch((e) => toast(e.message));
const A = {
  tab: (id) => go(id),
  logout: () => run(async () => { await api('/logout', 'POST').catch(() => {}); signOut(); }),
  login: () => run(async () => enter(await api('/login', 'POST', { username: val('lu').trim(), password: val('lp') }))),
  register: () => run(async () => enter(await api('/register', 'POST', { phone: val('rs').trim(), name: val('rn'), password: val('rp') }))),
  chpw: () => run(async () => {
    if (val('pn') !== val('pc')) return toast('Mật khẩu nhập lại không khớp');
    const r = await api('/change-password', 'POST', { old_password: val('po'), new_password: val('pn') });
    token = r.token; localStorage.setItem('token', token);
    render(); toast('Đã đổi mật khẩu');
  }),
  resetpw: () => run(async () => {
    const r = await api('/reset-password', 'POST', { phone: val('rsp'), new_password: val('rsw') });
    render(); toast(`Đã cấp lại mật khẩu cho ${r.name}`);
  }),
  cat: (id) => { cat = id; render(); },
  pay: (id) => { pay = id; render(); },
  add: (id) => {
    const m = menu.find((x) => x.id === +id);
    if ((cart[id] || 0) >= m.stock) return toast('Không đủ hàng trong kho');
    cart[id] = (cart[id] || 0) + 1; render();
  },
  dec: (id) => { if (--cart[id] <= 0) delete cart[id]; render(); },
  clear: () => { cart = {}; render(); },
  checkout: () => run(async () => {
    const items = Object.entries(cart).map(([id, qty]) => ({ id: +id, qty }));
    if (!items.length) return toast('Đơn đang trống, hãy chọn món trước');
    const body = { items, pay };
    if (pay === 'card') { body.card_code = val('cm'); body.password = val('cp'); }
    const r = await api('/orders', 'POST', body);
    cart = {}; menu = await api('/menu'); render(); toast('Đã thanh toán ' + vnd(r.total));
  }),
  topup: () => run(async () => {
    const r = await api('/topups', 'POST', { card_code: val('tc'), amount: +val('ta') });
    render(); toast(`Đã nạp cho ${r.name}, số dư ${vnd(r.balance)}`);
  }),
  addm: () => run(async () => {
    await api('/menu', 'POST', { name: val('nn'), category: val('nc'), price: +val('np'), stock: +val('ns') || 0 });
    await go('menu'); toast('Đã thêm món');
  }),
  delm: (id) => run(async () => {
    if (delId !== +id) { delId = +id; return render(); }
    await api('/menu/' + id, 'DELETE'); delete cart[id]; await go('menu'); toast('Đã xóa món');
  }),
};
document.addEventListener('click', (e) => {
  const b = e.target.closest('[data-act]');
  if (b && !b.disabled && A[b.dataset.act]) A[b.dataset.act](b.dataset.id);
});
document.addEventListener('change', (e) => {
  const t = e.target;
  if (t.dataset.mon) { if (t.value) { month = t.value; run(() => go('rep')); } return; }
  if (t.dataset.chg) run(async () => {
    await api('/menu/' + t.dataset.id, 'PATCH', { [t.dataset.chg]: +t.value });
    menu = await api('/menu'); render();
  });
});

(async () => {
  if (token) { try { me = await api('/me'); } catch { me = null; } }
  if (me) await go(TABS[me.role][0][0]); else render();
})();
