# CHƯƠNG 4. CÀI ĐẶT VÀ THỬ NGHIỆM HỆ THỐNG

> Các mục `[Chèn ...]` là minh chứng bạn cần tự chụp/lấy từ lần chạy thật của mình (ảnh màn hình, log, URL repo).

## 4.1. Lựa chọn công nghệ và môi trường phát triển
**4.1.1. Ngôn ngữ lập trình.** JavaScript (Node.js 22, ES Modules) cho cả máy chủ và giao diện; SQL cho CSDL. Dùng một ngôn ngữ cho cả hai phía giúp giảm chi phí học và dễ bảo trì.

**4.1.2. Framework và thư viện.** Máy chủ dùng module `node:http` có sẵn với bộ định tuyến tự viết (`src/server.js`), không dùng framework ngoài để hệ thống nhỏ gọn, ít lỗ hổng chuỗi cung ứng và khởi động nhanh. Mã hóa mật khẩu dùng `node:crypto` (scrypt). Giao diện dùng JavaScript thuần; chỉ có một thư viện ngoài là `qrcodejs` (CDN) để vẽ mã QR. Công cụ dev: ESLint, Prettier. Kiểm thử: `node:test`.

**4.1.3. Hệ quản trị CSDL.** SQLite qua `node:sqlite`. Căng tin của một trường là hệ thống một điểm triển khai, dữ liệu nhỏ, nên SQLite (một tệp, có giao dịch ACID, khóa ngoại, ràng buộc CHECK) là đủ và không cần cài máy chủ CSDL riêng.

**4.1.4. Môi trường và công cụ.** Node.js ≥ 22.13, npm, Git + GitHub, VS Code, Docker (tùy chọn), GitHub Actions. Trình duyệt Chrome/Edge để chạy thử. [Chèn: ảnh phiên bản `node -v`, `git --version`]

**4.1.5. Sự phù hợp.** Yêu cầu của căng-tin: ít người dùng đồng thời, cần giao dịch chính xác (trừ kho, trừ số dư), dễ triển khai trên máy tính của nhà trường. Bộ công nghệ trên đáp ứng đủ, cài đặt chỉ cần Node.js. Hạn chế: SQLite không phù hợp nếu mở rộng thành nhiều máy chủ ghi đồng thời; khi đó có thể chuyển sang PostgreSQL mà chỉ cần thay `src/db.js`.

## 4.2. Tổ chức và quản lý mã nguồn
**4.2.1. Cấu trúc.** Phân tầng: `src/server.js` (HTTP, định tuyến, phân quyền) → `src/services.js` (nghiệp vụ) → `src/db.js` + `db/schema.sql` (truy cập dữ liệu); `public/` (giao diện); `scripts/` (seed, build, create-admin); `test/`; `docs/`.

**4.2.2. Kho Git.** `git init`, tạo repo GitHub, `git remote add origin <URL>`, `git push -u origin main`. [Chèn: URL repo và ảnh trang repo]

**4.2.3. Quy ước.** Mã: `.editorconfig`, Prettier (nháy đơn, rộng 100), ESLint khuyến nghị. Commit theo Conventional Commits (`feat:`, `fix:`, `test:`, `ci:`, `docs:`, `chore:`). Phiên bản theo SemVer (`1.0.0` trong `package.json`), gắn tag `v1.0.0` khi phát hành.

**4.2.4. Nhánh và tích hợp.** `main` (ổn định) ← `develop` (tích hợp) ← `feature/*`. Mỗi chức năng làm trên nhánh riêng, gộp vào `develop` bằng Pull Request (CI phải xanh), phát hành thì gộp `develop` vào `main`. Lịch sử mẫu có sẵn trong thư mục `.git` kèm theo. [Chèn: ảnh `git log --graph --oneline --all`]

**4.2.5. Rà soát chất lượng.** Checklist rà soát PR: (1) có test cho logic mới; (2) lint/format xanh; (3) mọi đầu vào được kiểm tra hợp lệ; (4) không ghi mật khẩu dạng rõ; (5) truy vấn SQL dùng tham số hóa. Kết quả đánh giá: [điền sau khi chạy `npm run lint` và `npm test`].

## 4.3. Cài đặt cơ sở dữ liệu
**4.3.1. Tạo CSDL từ thiết kế.** Tệp `db/schema.sql` được áp dụng tự động khi khởi động (`openDb`). Có 7 bảng: `users`, `students`, `menu_items`, `orders`, `order_items`, `topups`, `sessions`.

**4.3.2. Bảng, khóa, ràng buộc.** Khóa chính tự tăng; khóa ngoại bật `PRAGMA foreign_keys=ON`; `UNIQUE` cho `username`, `phone`, `card_code`; `CHECK`: `price > 0`, `stock >= 0`, `balance >= 0`, `qty > 0`, vai trò và hình thức thanh toán thuộc tập hợp cho phép, và đơn thanh toán thẻ bắt buộc có sinh viên (`(pay_method='card') = (student_id IS NOT NULL)`). `order_items` lưu tên và giá tại thời điểm bán để báo cáo không đổi khi sửa thực đơn. Món bị xóa chỉ ẩn (`active=0`) để giữ lịch sử đơn. [Chèn: sơ đồ ERD]

**4.3.3. Chức năng truy cập và xử lý dữ liệu.** `src/services.js`: `checkout`, `topup` chạy trong giao dịch (`tx`) nên lỗi giữa chừng sẽ hoàn tác toàn bộ; báo cáo tổng hợp bằng `GROUP BY`; chỉ mục trên `orders(created_at)`, `orders(student_id)`.

**4.3.4. Dữ liệu mẫu.** Theo yêu cầu, ứng dụng chạy bình thường **không có dữ liệu mẫu**. Dữ liệu mẫu nằm riêng trong `scripts/seed.js` (`npm run seed`) chỉ phục vụ kiểm thử và trình diễn: 2 tài khoản nhân viên, 10 món, không có sinh viên mẫu.

## 4.4. Cài đặt các chức năng của hệ thống
**4.4.1. Nghiệp vụ.** `services.js`: đăng ký thẻ (cấp mã thẻ ngẫu nhiên), quản lý thực đơn/kho, thanh toán tiền mặt/thẻ, nạp tiền, xem thẻ, báo cáo ngày/tháng.
**4.4.2. Truy cập dữ liệu.** Câu lệnh SQL tham số hóa (`db.prepare(...).run/get/all`), chống SQL injection.
**4.4.3. Giao diện.** `public/` — theo vai trò: bán hàng, thực đơn & kho, báo cáo, thẻ của tôi; hồng pastel, hỗ trợ giao diện tối và điện thoại. [Chèn: ảnh từng màn hình]
**4.4.4. Xác thực và phân quyền.** Mật khẩu băm scrypt kèm salt; phiên đăng nhập bằng token ngẫu nhiên hết hạn sau 12 giờ; khóa 60 giây sau 5 lần sai; bảng phân quyền theo tuyến API (xem `routes` trong `server.js`): quản lý – tất cả; thu ngân – bán hàng, nạp tiền; sinh viên – chỉ xem thẻ của chính mình.
**4.4.5. Tích hợp.** Giao diện gọi REST API `/api/*` (JSON); máy chủ phục vụ luôn tệp tĩnh; kiểm thử API tích hợp trong `test/api.test.js`.
**4.4.6. Đối chiếu yêu cầu.**

| Yêu cầu | Cài đặt | Minh chứng |
|---|---|---|
| Thẻ riêng tư theo từng sinh viên | `/api/my/card`, đăng nhập số điện thoại + mật khẩu | test "thẻ riêng tư" |
| Mã QR riêng, không dùng số điện thoại làm mã thẻ | `card_code` ngẫu nhiên + QR | test "mỗi thẻ một mã riêng" |
| Báo cáo theo tháng | `/api/reports/monthly` | test "báo cáo tháng" |
| Không có dữ liệu mẫu trong app | CSDL trống khi khởi động | `scripts/seed.js` tách riêng |
| Trừ kho / số dư chính xác | giao dịch + CHECK | test hoàn tác, test 402 |

## 4.5. Tự động hóa xây dựng và tích hợp
**4.5.1. Quản lý phụ thuộc.** `package.json` (npm); ứng dụng không có phụ thuộc chạy, chỉ có `devDependencies` (eslint, prettier, globals).
**4.5.2. Biên dịch/đóng gói.** `npm run build`: kiểm tra cú pháp mọi tệp `.js` (`node --check`) rồi chép sản phẩm vào `dist/`; `Dockerfile` đóng gói thành image.
**4.5.3. Định dạng và phân tích tĩnh.** `npm run lint` (ESLint) và `npm run format:check` (Prettier).
**4.5.4. CI.** `.github/workflows/ci.yml`: mỗi lần push/PR chạy cài đặt → lint → format → test → build → tải artifact `dist` → build Docker image.
**4.5.5. Ghi nhận kết quả.** [Chèn: ảnh trang Actions xanh, log `npm test` (11 test), thời gian chạy]

## 4.6. Triển khai và thử nghiệm
**4.6.1. Cấu hình.** Biến môi trường `PORT`, `DB_FILE`, `TZ_OFFSET_MIN`; Docker volume cho dữ liệu.
**4.6.2. Cài đặt và khởi động.** Các bước trong `README.md` (Node: `npm run create-admin`, `npm start`; Docker: `docker compose up --build`).
**4.6.3. Chạy thử luồng chính.** (1) Quản lý tạo tài khoản, thêm món. (2) Sinh viên đăng ký thẻ, xem QR. (3) Thu ngân nạp tiền theo mã thẻ. (4) Thu ngân bán hàng bằng thẻ (nhập mật khẩu). (5) Quản lý xem báo cáo ngày/tháng. [Chèn: ảnh từng bước]
**4.6.4. Kết nối và tích hợp.** Giao diện ↔ API ↔ SQLite; kiểm tra bằng `test/api.test.js` và chạy thật bằng `curl`.
**4.6.5. Vấn đề phát sinh.** Bảng ghi: [Vấn đề — nguyên nhân — cách xử lý]. Ví dụ đã gặp khi phát triển: thứ tự "bán chạy" tính theo số lượng chứ không theo doanh thu — đã sửa kỳ vọng của test cho đúng định nghĩa.
**4.6.6. Tài liệu.** `README.md` (cài đặt, cấu hình, hướng dẫn dùng).

## 4.7. Công cụ hỗ trợ
VS Code (IDE); Git + GitHub (mã nguồn); npm (phụ thuộc, script); GitHub Actions (CI); Docker (môi trường đồng nhất).

**Sản phẩm Chương 4:** mã nguồn + lịch sử Git; `db/schema.sql` + `scripts/seed.js`; ứng dụng chạy thử; `README.md`; `ci.yml`, `Dockerfile`; log build/test; ảnh minh chứng.
