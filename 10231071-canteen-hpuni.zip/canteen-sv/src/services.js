import { randomBytes } from 'node:crypto';
import { tx } from './db.js';
import { AppError } from './errors.js';
import { createSession, hashPassword, verifyPassword } from './auth.js';

const OFF = Number(process.env.TZ_OFFSET_MIN ?? 420) * 60000; // mặc định UTC+7 (Việt Nam)
const ALPHABET = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
const isInt = (n, min) => Number.isInteger(n) && n >= min;

/** Chuẩn hóa số điện thoại VN: bỏ khoảng trắng/dấu chấm/gạch, +84 hoặc 84 → 0. Không phải SĐT thì trả nguyên văn. */
export function normalizePhone(input) {
  const raw = String(input ?? '').trim();
  const s = raw.replace(/[\s.-]/g, '').replace(/^\+?84/, '0');
  return /^0\d{9}$/.test(s) ? s : raw;
}

/* ---------- Người dùng & xác thực ---------- */
export function createUser(db, { username, full_name, role, password }) {
  const r = db
    .prepare('INSERT INTO users(username, full_name, role, pass_hash, created_at) VALUES (?,?,?,?,?)')
    .run(username, full_name, role, hashPassword(password), Date.now());
  return Number(r.lastInsertRowid);
}

const fails = new Map(); // chống dò mật khẩu: khóa 60 giây sau 5 lần sai
const checkLock = (key) => {
  const f = fails.get(key);
  if (f && f.n >= 5 && f.until > Date.now()) throw new AppError(429, 'Sai quá nhiều lần, thử lại sau 1 phút');
  return f;
};
const addFail = (key, f) => fails.set(key, { n: (f && f.until > Date.now() ? f.n : 0) + 1, until: Date.now() + 60000 });

function checkPassword(password) {
  const pw = String(password ?? '');
  if (pw.length < 6 || pw.length > 64) throw new AppError(400, 'Mật khẩu gồm 6 đến 64 ký tự');
  return pw;
}

export function login(db, { username, password } = {}) {
  const key = normalizePhone(username);
  const f = checkLock(key);
  const u = db.prepare('SELECT * FROM users WHERE username = ?').get(key);
  if (!u || !verifyPassword(String(password ?? ''), u.pass_hash)) {
    addFail(key, f);
    throw new AppError(401, 'Sai tên đăng nhập hoặc mật khẩu');
  }
  fails.delete(key);
  return { token: createSession(db, u.id), user: { id: u.id, full_name: u.full_name, role: u.role } };
}

/** Tự đổi mật khẩu: phải nhập đúng mật khẩu cũ. Mọi phiên khác bị đăng xuất, phiên hiện tại được cấp token mới. */
export function changePassword(db, user, { old_password, new_password } = {}) {
  const key = 'pw:' + user.username;
  const f = checkLock(key);
  const u = db.prepare('SELECT pass_hash FROM users WHERE id = ?').get(user.id);
  if (!u || !verifyPassword(String(old_password ?? ''), u.pass_hash)) {
    addFail(key, f);
    throw new AppError(401, 'Mật khẩu hiện tại không đúng');
  }
  const pw = checkPassword(new_password);
  if (pw === String(old_password)) throw new AppError(400, 'Mật khẩu mới phải khác mật khẩu cũ');
  fails.delete(key);
  return tx(db, () => {
    db.prepare('UPDATE users SET pass_hash = ? WHERE id = ?').run(hashPassword(pw), user.id);
    db.prepare('DELETE FROM sessions WHERE user_id = ?').run(user.id);
    return { token: createSession(db, user.id) };
  });
}

/** Quên mật khẩu: nhân viên cấp lại mật khẩu cho sinh viên (sau khi xác minh trực tiếp tại quầy). */
export function resetStudentPassword(db, { phone, new_password } = {}) {
  const key = normalizePhone(phone);
  const pw = checkPassword(new_password);
  const s = db
    .prepare("SELECT u.id, u.full_name FROM users u JOIN students s ON s.user_id = u.id WHERE u.username = ? AND u.role = 'student'")
    .get(key);
  if (!s) throw new AppError(404, 'Không tìm thấy sinh viên với số điện thoại này');
  tx(db, () => {
    db.prepare('UPDATE users SET pass_hash = ? WHERE id = ?').run(hashPassword(pw), s.id);
    db.prepare('DELETE FROM sessions WHERE user_id = ?').run(s.id);
  });
  fails.delete(key);
  fails.delete('pw:' + key);
  return { name: s.full_name };
}

export function logout(db, token) {
  db.prepare('DELETE FROM sessions WHERE token = ?').run(token);
  return { ok: true };
}

function newCardCode(db) {
  for (;;) {
    const code = 'SV' + Array.from(randomBytes(6), (b) => ALPHABET[b % 32]).join('');
    if (!db.prepare('SELECT 1 FROM students WHERE card_code = ?').get(code)) return code;
  }
}

export function register(db, { phone, name, password } = {}) {
  phone = normalizePhone(phone);
  if (!/^0\d{9}$/.test(phone)) throw new AppError(400, 'Số điện thoại gồm 10 số, bắt đầu bằng 0');
  if (String(name ?? '').trim().length < 2) throw new AppError(400, 'Nhập họ tên');
  const pw = checkPassword(password);
  if (db.prepare('SELECT 1 FROM users WHERE username = ?').get(phone)) throw new AppError(409, 'Số điện thoại này đã có thẻ');
  tx(db, () => {
    const id = createUser(db, { username: phone, full_name: name.trim(), role: 'student', password: pw });
    db.prepare('INSERT INTO students(user_id, phone, card_code) VALUES (?,?,?)').run(id, phone, newCardCode(db));
  });
  return login(db, { username: phone, password: pw });
}

/* ---------- Thực đơn & kho ---------- */
export const listMenu = (db) =>
  db.prepare('SELECT id, name, category, price, stock FROM menu_items WHERE active = 1 ORDER BY category, name').all().map((r) => ({ ...r }));

function checkItem({ name, category, price, stock }, partial) {
  const out = {};
  if (!partial || name !== undefined) {
    if (!String(name ?? '').trim()) throw new AppError(400, 'Nhập tên món');
    out.name = String(name).trim();
  }
  if (!partial || category !== undefined) out.category = String(category || 'Khác').trim();
  if (!partial || price !== undefined) {
    if (!isInt(price, 1)) throw new AppError(400, 'Giá phải là số nguyên lớn hơn 0');
    out.price = price;
  }
  if (!partial || stock !== undefined) {
    if (!isInt(stock ?? 0, 0)) throw new AppError(400, 'Tồn kho phải là số nguyên không âm');
    out.stock = stock ?? 0;
  }
  return out;
}

export function addItem(db, body = {}) {
  const v = checkItem(body, false);
  const r = db.prepare('INSERT INTO menu_items(name, category, price, stock) VALUES (?,?,?,?)').run(v.name, v.category, v.price, v.stock);
  return { id: Number(r.lastInsertRowid), ...v };
}

export function updateItem(db, id, body = {}) {
  const v = checkItem(body, true);
  const keys = Object.keys(v);
  if (!keys.length) throw new AppError(400, 'Không có gì để cập nhật');
  const r = db.prepare(`UPDATE menu_items SET ${keys.map((k) => `${k} = ?`).join(', ')} WHERE id = ? AND active = 1`).run(...keys.map((k) => v[k]), id);
  if (!r.changes) throw new AppError(404, 'Không tìm thấy món');
  return { id, ...v };
}

export function removeItem(db, id) {
  const r = db.prepare('UPDATE menu_items SET active = 0 WHERE id = ? AND active = 1').run(id);
  if (!r.changes) throw new AppError(404, 'Không tìm thấy món');
  return { ok: true };
}

/* ---------- Bán hàng ---------- */
export function checkout(db, cashierId, { items, pay, card_code, password } = {}) {
  if (!Array.isArray(items) || !items.length) throw new AppError(400, 'Đơn đang trống');
  if (!['cash', 'card'].includes(pay)) throw new AppError(400, 'Hình thức thanh toán không hợp lệ');
  const want = new Map();
  for (const { id, qty } of items) {
    if (!isInt(id, 1) || !isInt(qty, 1)) throw new AppError(400, 'Dữ liệu món không hợp lệ');
    want.set(id, (want.get(id) ?? 0) + qty);
  }
  return tx(db, () => {
    let total = 0;
    const lines = [];
    for (const [id, qty] of want) {
      const m = db.prepare('SELECT * FROM menu_items WHERE id = ? AND active = 1').get(id);
      if (!m) throw new AppError(404, 'Món không tồn tại');
      if (m.stock < qty) throw new AppError(409, `Không đủ hàng: ${m.name}`);
      lines.push({ m, qty });
      total += m.price * qty;
    }
    let student = null;
    if (pay === 'card') {
      student = db
        .prepare('SELECT s.user_id, s.balance, u.pass_hash FROM students s JOIN users u ON u.id = s.user_id WHERE s.card_code = ?')
        .get(String(card_code ?? '').trim().toUpperCase());
      if (!student || !verifyPassword(String(password ?? ''), student.pass_hash)) throw new AppError(401, 'Mã thẻ hoặc mật khẩu không đúng');
      if (student.balance < total) throw new AppError(402, 'Số dư thẻ không đủ');
      db.prepare('UPDATE students SET balance = balance - ? WHERE user_id = ?').run(total, student.user_id);
    }
    const r = db
      .prepare('INSERT INTO orders(created_at, pay_method, total, student_id, cashier_id) VALUES (?,?,?,?,?)')
      .run(Date.now(), pay, total, student ? student.user_id : null, cashierId);
    const orderId = Number(r.lastInsertRowid);
    for (const { m, qty } of lines) {
      db.prepare('UPDATE menu_items SET stock = stock - ? WHERE id = ?').run(qty, m.id);
      db.prepare('INSERT INTO order_items(order_id, item_id, name, price, qty) VALUES (?,?,?,?,?)').run(orderId, m.id, m.name, m.price, qty);
    }
    return { id: orderId, total };
  });
}

export function topup(db, staffId, { card_code, amount } = {}) {
  if (!isInt(amount, 1000) || amount > 5000000) throw new AppError(400, 'Số tiền nạp từ 1.000đ đến 5.000.000đ');
  return tx(db, () => {
    const s = db
      .prepare('SELECT s.user_id, u.full_name FROM students s JOIN users u ON u.id = s.user_id WHERE s.card_code = ?')
      .get(String(card_code ?? '').trim().toUpperCase());
    if (!s) throw new AppError(404, 'Không tìm thấy thẻ');
    db.prepare('UPDATE students SET balance = balance + ? WHERE user_id = ?').run(amount, s.user_id);
    db.prepare('INSERT INTO topups(student_id, amount, staff_id, created_at) VALUES (?,?,?,?)').run(s.user_id, amount, staffId, Date.now());
    const { balance } = db.prepare('SELECT balance FROM students WHERE user_id = ?').get(s.user_id);
    return { name: s.full_name, balance };
  });
}

export function studentCard(db, userId) {
  const s = db
    .prepare('SELECT u.full_name, s.phone, s.card_code, s.balance FROM students s JOIN users u ON u.id = s.user_id WHERE s.user_id = ?')
    .get(userId);
  if (!s) throw new AppError(404, 'Không tìm thấy thẻ');
  const orders = db.prepare('SELECT id, created_at, total FROM orders WHERE student_id = ? ORDER BY id DESC LIMIT 15').all(userId).map((o) => ({
    ...o,
    items: db.prepare('SELECT name, qty FROM order_items WHERE order_id = ?').all(o.id).map((i) => ({ ...i })),
  }));
  return { ...s, orders };
}

/* ---------- Báo cáo ---------- */
function summarize(db, from, to) {
  const by = { cash: 0, card: 0 };
  let orders = 0;
  for (const r of db.prepare('SELECT pay_method, SUM(total) AS t, COUNT(*) AS n FROM orders WHERE created_at >= ? AND created_at < ? GROUP BY pay_method').all(from, to)) {
    by[r.pay_method] = r.t;
    orders += r.n;
  }
  const top = db
    .prepare(
      `SELECT oi.name, SUM(oi.qty) AS qty FROM order_items oi JOIN orders o ON o.id = oi.order_id
       WHERE o.created_at >= ? AND o.created_at < ? GROUP BY oi.name ORDER BY qty DESC LIMIT 5`,
    )
    .all(from, to)
    .map((r) => ({ ...r }));
  return { revenue: by.cash + by.card, orders, cash: by.cash, card: by.card, top };
}

export function dailyReport(db, date) {
  const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(String(date ?? ''));
  if (!m) throw new AppError(400, 'Ngày phải có dạng YYYY-MM-DD');
  const from = Date.UTC(+m[1], +m[2] - 1, +m[3]) - OFF;
  return { date, ...summarize(db, from, from + 864e5) };
}

export function monthlyReport(db, month) {
  const m = /^(\d{4})-(0[1-9]|1[0-2])$/.exec(String(month ?? ''));
  if (!m) throw new AppError(400, 'Tháng phải có dạng YYYY-MM');
  const y = +m[1], mo = +m[2];
  const start = Date.UTC(y, mo - 1, 1), end = Date.UTC(y, mo, 1);
  const days = Array.from({ length: (end - start) / 864e5 }, (_, i) => ({ day: i + 1, revenue: 0 }));
  for (const o of db.prepare('SELECT created_at, total FROM orders WHERE created_at >= ? AND created_at < ?').all(start - OFF, end - OFF)) {
    days[Math.floor((o.created_at + OFF - start) / 864e5)].revenue += o.total;
  }
  return { month, ...summarize(db, start - OFF, end - OFF), days };
}
