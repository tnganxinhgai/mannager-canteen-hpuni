import http from 'node:http';
import { readFile } from 'node:fs/promises';
import { extname, join, normalize } from 'node:path';
import { fileURLToPath } from 'node:url';
import { openDb } from './db.js';
import { authenticate } from './auth.js';
import { AppError } from './errors.js';
import * as svc from './services.js';

const PUBLIC = fileURLToPath(new URL('../public/', import.meta.url));
const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8' };
const STAFF = ['admin', 'cashier'];
const ANY = ['admin', 'cashier', 'student'];
const SECURITY = {
  'X-Content-Type-Options': 'nosniff',
  'Content-Security-Policy':
    "default-src 'self'; script-src 'self' https://cdnjs.cloudflare.com; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; font-src https://fonts.gstatic.com; img-src 'self' data:",
};

export function createServer(db) {
  // [method, đường dẫn, vai trò được phép (null = công khai), xử lý]
  const routes = [
    ['POST', '/api/login', null, (c) => svc.login(db, c.body)],
    ['POST', '/api/register', null, (c) => svc.register(db, c.body)],
    ['POST', '/api/logout', ANY, (c) => svc.logout(db, c.token)],
    ['POST', '/api/change-password', ANY, (c) => svc.changePassword(db, c.user, c.body)],
    ['POST', '/api/reset-password', STAFF, (c) => svc.resetStudentPassword(db, c.body)],
    ['GET', '/api/me', ANY, (c) => c.user],
    ['GET', '/api/menu', STAFF, () => svc.listMenu(db)],
    ['POST', '/api/menu', ['admin'], (c) => svc.addItem(db, c.body)],
    ['PATCH', '/api/menu/:id', ['admin'], (c) => svc.updateItem(db, +c.params.id, c.body)],
    ['DELETE', '/api/menu/:id', ['admin'], (c) => svc.removeItem(db, +c.params.id)],
    ['POST', '/api/orders', STAFF, (c) => svc.checkout(db, c.user.id, c.body)],
    ['POST', '/api/topups', STAFF, (c) => svc.topup(db, c.user.id, c.body)],
    ['GET', '/api/my/card', ['student'], (c) => svc.studentCard(db, c.user.id)],
    ['GET', '/api/reports/daily', ['admin'], (c) => svc.dailyReport(db, c.query.get('date'))],
    ['GET', '/api/reports/monthly', ['admin'], (c) => svc.monthlyReport(db, c.query.get('month'))],
  ].map(([method, path, roles, fn]) => ({ method, roles, fn, re: new RegExp('^' + path.replace(/:(\w+)/g, '(?<$1>[^/]+)') + '$') }));

  async function readBody(req) {
    let raw = '';
    for await (const chunk of req) {
      raw += chunk;
      if (raw.length > 100_000) throw new AppError(413, 'Dữ liệu quá lớn');
    }
    try {
      return raw ? JSON.parse(raw) : {};
    } catch {
      throw new AppError(400, 'JSON không hợp lệ');
    }
  }

  async function handleApi(req, res, url) {
    const route = routes.find((r) => r.method === req.method && r.re.test(url.pathname));
    if (!route) throw new AppError(404, 'Không tìm thấy');
    const token = (req.headers.authorization || '').replace(/^Bearer /, '');
    const user = authenticate(db, token);
    if (route.roles && !user) throw new AppError(401, 'Cần đăng nhập');
    if (route.roles && !route.roles.includes(user.role)) throw new AppError(403, 'Không đủ quyền');
    const body = ['POST', 'PATCH'].includes(req.method) ? await readBody(req) : {};
    const params = { ...route.re.exec(url.pathname).groups };
    const out = await route.fn({ body, user, token, params, query: url.searchParams });
    send(res, 200, out);
  }

  const send = (res, status, data) => {
    res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', ...SECURITY });
    res.end(JSON.stringify(data));
  };

  async function serveStatic(pathname, res) {
    const file = normalize(join(PUBLIC, pathname === '/' ? 'index.html' : pathname));
    if (!file.startsWith(PUBLIC)) return send(res, 403, { error: 'Không đủ quyền' });
    try {
      const data = await readFile(file);
      res.writeHead(200, { 'Content-Type': MIME[extname(file)] || 'application/octet-stream', ...SECURITY });
      res.end(data);
    } catch {
      send(res, 404, { error: 'Không tìm thấy' });
    }
  }

  return http.createServer(async (req, res) => {
    try {
      const url = new URL(req.url, 'http://localhost');
      if (url.pathname.startsWith('/api/')) await handleApi(req, res, url);
      else await serveStatic(url.pathname, res);
    } catch (err) {
      if (err instanceof AppError) return send(res, err.status, { error: err.message });
      if (/UNIQUE|CHECK|FOREIGN KEY/.test(String(err.message))) return send(res, 409, { error: 'Dữ liệu vi phạm ràng buộc' });
      console.error(err);
      send(res, 500, { error: 'Lỗi hệ thống' });
    }
  });
}

if (process.argv[1] === fileURLToPath(import.meta.url)) {
  const port = Number(process.env.PORT || 3000);
  createServer(openDb()).listen(port, () => console.log(`Căng tin HPUni chạy tại http://localhost:${port}`));
}
