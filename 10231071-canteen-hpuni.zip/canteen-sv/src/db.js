import { DatabaseSync } from 'node:sqlite';
import { mkdirSync, readFileSync } from 'node:fs';
import { dirname } from 'node:path';

/** Mở CSDL SQLite và áp dụng lược đồ. Dùng ':memory:' cho kiểm thử. */
export function openDb(file = process.env.DB_FILE || 'data/canteen.db') {
  if (file !== ':memory:') mkdirSync(dirname(file), { recursive: true });
  const db = new DatabaseSync(file);
  db.exec('PRAGMA foreign_keys = ON; PRAGMA journal_mode = WAL;');
  // Nâng cấp CSDL cũ: cột students.mssv được đổi tên thành students.phone (chạy trước schema mới).
  const cols = db.prepare("SELECT name FROM pragma_table_info('students')").all().map((c) => c.name);
  if (cols.includes('mssv')) db.exec('ALTER TABLE students RENAME COLUMN mssv TO phone');
  db.exec(readFileSync(new URL('../db/schema.sql', import.meta.url), 'utf8'));
  return db;
}

/** Chạy fn trong một giao dịch; lỗi thì ROLLBACK toàn bộ. */
export function tx(db, fn) {
  db.exec('BEGIN');
  try {
    const out = fn();
    db.exec('COMMIT');
    return out;
  } catch (err) {
    db.exec('ROLLBACK');
    throw err;
  }
}
