// Dùng: npm run reset-password -- <tên đăng nhập hoặc SĐT> <mật khẩu mới ≥ 6 ký tự>
import { openDb } from '../src/db.js';
import { hashPassword } from '../src/auth.js';
import { normalizePhone } from '../src/services.js';

const [user, password] = process.argv.slice(2);
if (!user || !password || password.length < 6 || password.length > 64) {
  console.error('Cách dùng: npm run reset-password -- <tên đăng nhập> <mật khẩu mới 6–64 ký tự>');
  process.exit(1);
}
const db = openDb();
const u = db.prepare('SELECT id FROM users WHERE username = ?').get(normalizePhone(user));
if (!u) {
  console.error('Không tìm thấy tài khoản.');
  process.exit(1);
}
db.prepare('UPDATE users SET pass_hash = ? WHERE id = ?').run(hashPassword(password), u.id);
db.prepare('DELETE FROM sessions WHERE user_id = ?').run(u.id);
console.log(`Đã đặt lại mật khẩu cho "${user}".`);
