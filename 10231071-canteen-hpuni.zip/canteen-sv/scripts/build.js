// "Biên dịch" = kiểm tra cú pháp mọi tệp .js rồi đóng gói thư mục dist/ để triển khai.
import { spawnSync } from 'node:child_process';
import { cpSync, mkdirSync, readdirSync, rmSync, statSync } from 'node:fs';
import { join } from 'node:path';

const walk = (d) => readdirSync(d).flatMap((f) => (statSync(join(d, f)).isDirectory() ? walk(join(d, f)) : [join(d, f)]));
const files = ['src', 'scripts', 'public', 'test'].flatMap(walk).filter((f) => f.endsWith('.js'));
let bad = 0;
for (const f of files) {
  const r = spawnSync(process.execPath, ['--check', f], { encoding: 'utf8' });
  if (r.status !== 0) { bad++; console.error(`✗ ${f}\n${r.stderr}`); }
}
if (bad) process.exit(1);
console.log(`✓ Cú pháp hợp lệ: ${files.length} tệp`);
rmSync('dist', { recursive: true, force: true });
mkdirSync('dist');
for (const p of ['src', 'public', 'db', 'package.json']) cpSync(p, join('dist', p), { recursive: true });
console.log('✓ Đã đóng gói vào dist/');
