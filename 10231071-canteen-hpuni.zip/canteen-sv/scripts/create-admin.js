// Dùng: npm run create-admin -- <tên đăng nhập> <mật khẩu> "<họ tên>"
import { openDb } from '../src/db.js';
import { createUser } from '../src/services.js';

const [username, password, fullName = 'Quản lý'] = process.argv.slice(2);
if (!username || !password || password.length < 6) {
  console.error('Cách dùng: npm run create-admin -- <tên đăng nhập> <mật khẩu ≥ 6 ký tự> "<họ tên>"');
  process.exit(1);
}
createUser(openDb(), { username, full_name: fullName, role: 'admin', password });
console.log(`Đã tạo tài khoản quản lý "${username}".`);
