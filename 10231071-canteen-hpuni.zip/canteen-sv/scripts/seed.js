// DỮ LIỆU MẪU CHỈ DÙNG ĐỂ KIỂM THỬ/DEMO. Ứng dụng khi chạy bình thường KHÔNG tự nạp dữ liệu này.
// Dùng: npm run seed   (đặt DB_FILE=... để chọn tệp CSDL)
import { openDb } from '../src/db.js';
import { createUser, addItem } from '../src/services.js';

const db = openDb();
if (db.prepare('SELECT COUNT(*) AS n FROM users').get().n > 0) {
  console.error('CSDL đã có dữ liệu, bỏ qua seed.');
  process.exit(1);
}
createUser(db, { username: 'admin', full_name: 'Quản lý Căng tin HPUni', role: 'admin', password: 'admin123' });
createUser(db, { username: 'thungan', full_name: 'Thu ngân 01', role: 'cashier', password: 'thungan123' });
[
  ['Cơm sườn', 'Món chính', 30000, 40], ['Cơm gà xối mỡ', 'Món chính', 30000, 35], ['Bún chả', 'Món chính', 35000, 25],
  ['Phở bò', 'Món chính', 35000, 25], ['Bánh mì trứng', 'Ăn nhẹ', 15000, 30], ['Xôi mặn', 'Ăn nhẹ', 12000, 20],
  ['Sữa chua', 'Ăn nhẹ', 10000, 4], ['Trà đá', 'Đồ uống', 3000, 100], ['Cà phê sữa', 'Đồ uống', 15000, 50], ['Nước cam', 'Đồ uống', 20000, 30],
].forEach(([name, category, price, stock]) => addItem(db, { name, category, price, stock }));
console.log('Đã nạp dữ liệu mẫu: admin/admin123, thungan/thungan123 và 10 món. Sinh viên tự đăng ký thẻ trên giao diện.');
