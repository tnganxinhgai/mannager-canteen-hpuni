-- Lược đồ CSDL Căng tin HPUni (SQLite). Chạy lại nhiều lần vẫn an toàn (IF NOT EXISTS).
CREATE TABLE IF NOT EXISTS users (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  username   TEXT    NOT NULL UNIQUE,
  full_name  TEXT    NOT NULL,
  role       TEXT    NOT NULL CHECK (role IN ('admin', 'cashier', 'student')),
  pass_hash  TEXT    NOT NULL,
  created_at INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS students (
  user_id   INTEGER PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
  phone     TEXT    NOT NULL UNIQUE,            -- số điện thoại (10 số, bắt đầu bằng 0), cũng là tên đăng nhập
  card_code TEXT    NOT NULL UNIQUE,            -- mã thẻ ngẫu nhiên, in thành QR
  balance   INTEGER NOT NULL DEFAULT 0 CHECK (balance >= 0)
);

CREATE TABLE IF NOT EXISTS menu_items (
  id       INTEGER PRIMARY KEY AUTOINCREMENT,
  name     TEXT    NOT NULL,
  category TEXT    NOT NULL DEFAULT 'Khác',
  price    INTEGER NOT NULL CHECK (price > 0),
  stock    INTEGER NOT NULL DEFAULT 0 CHECK (stock >= 0),
  active   INTEGER NOT NULL DEFAULT 1 CHECK (active IN (0, 1))
);

CREATE TABLE IF NOT EXISTS orders (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  created_at INTEGER NOT NULL,
  pay_method TEXT    NOT NULL CHECK (pay_method IN ('cash', 'card')),
  total      INTEGER NOT NULL CHECK (total >= 0),
  student_id INTEGER REFERENCES students(user_id),
  cashier_id INTEGER NOT NULL REFERENCES users(id),
  CHECK ((pay_method = 'card') = (student_id IS NOT NULL))
);
CREATE INDEX IF NOT EXISTS idx_orders_created ON orders(created_at);
CREATE INDEX IF NOT EXISTS idx_orders_student ON orders(student_id);

CREATE TABLE IF NOT EXISTS order_items (
  id       INTEGER PRIMARY KEY AUTOINCREMENT,
  order_id INTEGER NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
  item_id  INTEGER NOT NULL REFERENCES menu_items(id),
  name     TEXT    NOT NULL,                    -- lưu lại tên/giá tại thời điểm bán
  price    INTEGER NOT NULL CHECK (price > 0),
  qty      INTEGER NOT NULL CHECK (qty > 0)
);
CREATE INDEX IF NOT EXISTS idx_items_order ON order_items(order_id);

CREATE TABLE IF NOT EXISTS topups (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  student_id INTEGER NOT NULL REFERENCES students(user_id),
  amount     INTEGER NOT NULL CHECK (amount > 0),
  staff_id   INTEGER NOT NULL REFERENCES users(id),
  created_at INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS sessions (
  token      TEXT    PRIMARY KEY,
  user_id    INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  expires_at INTEGER NOT NULL
);
