import { test, before, after } from 'node:test';
import assert from 'node:assert/strict';
import { openDb } from '../src/db.js';
import { createServer } from '../src/server.js';
import * as svc from '../src/services.js';

let server, base;
before(async () => {
  const db = openDb(':memory:');
  svc.createUser(db, { username: 'admin', full_name: 'Quản lý', role: 'admin', password: 'admin123' });
  svc.register(db, { phone: '0900000100', name: 'Một', password: '111111' });
  svc.register(db, { phone: '0900000200', name: 'Hai', password: '222222' });
  server = createServer(db);
  await new Promise((r) => server.listen(0, r));
  base = `http://localhost:${server.address().port}`;
});
after(() => server.close());

const call = async (path, { token, method = 'GET', body } = {}) => {
  const res = await fetch(base + path, {
    method,
    headers: { 'Content-Type': 'application/json', ...(token ? { Authorization: `Bearer ${token}` } : {}) },
    body: body ? JSON.stringify(body) : undefined,
  });
  return { status: res.status, json: await res.json().catch(() => null) };
};
const tokenOf = async (username, password) => (await call('/api/login', { method: 'POST', body: { username, password } })).json.token;

test('API cần đăng nhập: không có token → 401', async () => {
  assert.equal((await call('/api/menu')).status, 401);
  assert.equal((await call('/api/login', { method: 'POST', body: { username: 'admin', password: 'sai' } })).status, 401);
});

test('phân quyền: sinh viên không xem được báo cáo, quản lý thì được', async () => {
  const sv = await tokenOf('0900000100', '111111');
  const ad = await tokenOf('admin', 'admin123');
  assert.equal((await call('/api/reports/monthly?month=2026-11', { token: sv })).status, 403);
  assert.equal((await call('/api/menu', { token: sv })).status, 403);
  const r = await call('/api/reports/monthly?month=2026-11', { token: ad });
  assert.equal(r.status, 200);
  assert.equal(r.json.days.length, 30);
});

test('thẻ riêng tư: mỗi sinh viên chỉ thấy thẻ của mình', async () => {
  const a = await call('/api/my/card', { token: await tokenOf('0900000100', '111111') });
  const b = await call('/api/my/card', { token: await tokenOf('0900000200', '222222') });
  assert.equal(a.json.phone, '0900000100');
  assert.equal(b.json.phone, '0900000200');
  assert.notEqual(a.json.card_code, b.json.card_code);
});

test('giao diện tĩnh được phục vụ', async () => {
  const res = await fetch(base + '/');
  assert.equal(res.status, 200);
  assert.match(res.headers.get('content-type'), /text\/html/);
});

test('API đổi mật khẩu & cấp lại mật khẩu: đúng quyền', async () => {
  const sv = await tokenOf('0900000200', '222222');
  const ad = await tokenOf('admin', 'admin123');
  assert.equal((await call('/api/reset-password', { token: sv, method: 'POST', body: { phone: '0900000100', new_password: 'hacked1' } })).status, 403);
  assert.equal((await call('/api/reset-password', { method: 'POST', body: {} })).status, 401);
  assert.equal((await call('/api/reset-password', { token: ad, method: 'POST', body: { phone: '0900000100', new_password: 'moi12345' } })).status, 200);
  assert.ok(await tokenOf('0900000100', 'moi12345'));
  const ch = await call('/api/change-password', { token: sv, method: 'POST', body: { old_password: '222222', new_password: 'moi222222' } });
  assert.equal(ch.status, 200);
  assert.equal((await call('/api/my/card', { token: sv })).status, 401); // token cũ hết hiệu lực
  assert.equal((await call('/api/my/card', { token: ch.json.token })).status, 200);
});
