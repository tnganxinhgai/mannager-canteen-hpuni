import { test } from 'node:test';
import assert from 'node:assert/strict';
import { openDb } from '../src/db.js';
import * as svc from '../src/services.js';

function setup() {
  const db = openDb(':memory:');
  const staff = svc.createUser(db, { username: 'tn', full_name: 'Thu ngân', role: 'cashier', password: 'abcdef' });
  const com = svc.addItem(db, { name: 'Cơm sườn', category: 'Món chính', price: 30000, stock: 5 });
  const tra = svc.addItem(db, { name: 'Trà đá', category: 'Đồ uống', price: 3000, stock: 2 });
  return { db, staff, com, tra };
}
const stockOf = (db, id) => db.prepare('SELECT stock FROM menu_items WHERE id = ?').get(id).stock;

test('thanh toán tiền mặt: trừ tồn kho và ghi đơn', () => {
  const { db, staff, com } = setup();
  const r = svc.checkout(db, staff, { items: [{ id: com.id, qty: 2 }], pay: 'cash' });
  assert.equal(r.total, 60000);
  assert.equal(stockOf(db, com.id), 3);
});

test('thanh toán thẻ: trừ số dư; sai mật khẩu bị từ chối', () => {
  const { db, staff, com } = setup();
  svc.register(db, { phone: '0900000001', name: 'An', password: '123456' });
  const { card_code } = db.prepare('SELECT card_code FROM students').get();
  svc.topup(db, staff, { card_code, amount: 100000 });
  assert.throws(() => svc.checkout(db, staff, { items: [{ id: com.id, qty: 1 }], pay: 'card', card_code, password: 'saimatkhau' }), { status: 401 });
  svc.checkout(db, staff, { items: [{ id: com.id, qty: 1 }], pay: 'card', card_code, password: '123456' });
  assert.equal(db.prepare('SELECT balance FROM students').get().balance, 70000);
});

test('số dư không đủ: trả 402 và không đổi tồn kho', () => {
  const { db, staff, com } = setup();
  svc.register(db, { phone: '0900000002', name: 'Bình', password: '123456' });
  const { card_code } = db.prepare('SELECT card_code FROM students').get();
  assert.throws(() => svc.checkout(db, staff, { items: [{ id: com.id, qty: 1 }], pay: 'card', card_code, password: '123456' }), { status: 402 });
  assert.equal(stockOf(db, com.id), 5);
});

test('đơn nhiều món thiếu hàng: hoàn tác toàn bộ giao dịch', () => {
  const { db, staff, com, tra } = setup();
  assert.throws(() => svc.checkout(db, staff, { items: [{ id: com.id, qty: 1 }, { id: tra.id, qty: 9 }], pay: 'cash' }), { status: 409 });
  assert.equal(stockOf(db, com.id), 5);
  assert.equal(db.prepare('SELECT COUNT(*) AS n FROM orders').get().n, 0);
});

test('đăng ký: kiểm tra SĐT, mật khẩu, SĐT trùng, mỗi thẻ một mã riêng', () => {
  const { db } = setup();
  assert.throws(() => svc.register(db, { phone: '0900000003', name: 'Chi', password: 'abc' }), { status: 400 });
  assert.throws(() => svc.register(db, { phone: '12345', name: 'Chi', password: '123456' }), { status: 400 });
  svc.register(db, { phone: '0900000003', name: 'Chi', password: '123456' });
  assert.throws(() => svc.register(db, { phone: '0900000003', name: 'Chi', password: '123456' }), { status: 409 });
  assert.throws(() => svc.register(db, { phone: '+84 900 000 003', name: 'Chi', password: '123456' }), { status: 409 }); // cùng số, khác cách viết
  svc.register(db, { phone: '0900000004', name: 'Dũng', password: '123456' });
  const codes = db.prepare('SELECT card_code FROM students').all().map((r) => r.card_code);
  assert.equal(new Set(codes).size, 2);
  assert.notEqual(codes[0], '0900000003');
});

test('ràng buộc CSDL: không cho giá âm hoặc số dư âm', () => {
  const { db } = setup();
  assert.throws(() => db.prepare('INSERT INTO menu_items(name, price) VALUES (?, ?)').run('X', -1), /CHECK/);
  assert.throws(() => svc.addItem(db, { name: 'Y', price: 0, stock: 1 }), { status: 400 });
});

test('báo cáo tháng và ngày cộng đúng doanh thu', () => {
  const { db, staff, com, tra } = setup();
  svc.checkout(db, staff, { items: [{ id: com.id, qty: 1 }], pay: 'cash' });
  svc.checkout(db, staff, { items: [{ id: tra.id, qty: 2 }], pay: 'cash' });
  const d = new Date(Date.now() + 420 * 60000);
  const p = (n) => String(n).padStart(2, '0');
  const month = `${d.getUTCFullYear()}-${p(d.getUTCMonth() + 1)}`;
  const m = svc.monthlyReport(db, month);
  assert.equal(m.revenue, 36000);
  assert.equal(m.orders, 2);
  assert.equal(m.days.reduce((s, x) => s + x.revenue, 0), 36000);
  assert.equal(svc.dailyReport(db, `${month}-${p(d.getUTCDate())}`).revenue, 36000);
  assert.equal(m.top[0].name, 'Trà đá'); // xếp theo số lượng bán
});

test('đăng nhập bằng SĐT viết theo nhiều dạng (0…, +84…, có khoảng trắng)', () => {
  const { db } = setup();
  svc.register(db, { phone: '0912345678', name: 'Lan', password: 'matkhau1' });
  for (const u of ['0912345678', '+84912345678', '091 234 5678']) {
    assert.equal(svc.login(db, { username: u, password: 'matkhau1' }).user.role, 'student');
  }
  assert.throws(() => svc.login(db, { username: '0912345678', password: 'sai' }), { status: 401 });
});

test('nâng cấp CSDL cũ: cột mssv được đổi thành phone, dữ liệu giữ nguyên', async () => {
  const { DatabaseSync } = await import('node:sqlite');
  const { mkdtempSync } = await import('node:fs');
  const { tmpdir } = await import('node:os');
  const { join } = await import('node:path');
  const file = join(mkdtempSync(join(tmpdir(), 'hpuni-')), 'old.db');
  const old = new DatabaseSync(file);
  old.exec(`CREATE TABLE users (id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT NOT NULL UNIQUE, full_name TEXT NOT NULL, role TEXT NOT NULL, pass_hash TEXT NOT NULL, created_at INTEGER NOT NULL);
    CREATE TABLE students (user_id INTEGER PRIMARY KEY REFERENCES users(id), mssv TEXT NOT NULL UNIQUE, card_code TEXT NOT NULL UNIQUE, balance INTEGER NOT NULL DEFAULT 0);
    INSERT INTO users VALUES (1,'20230001','Cũ','student','x:y',0); INSERT INTO students VALUES (1,'20230001','SVABCDEFGH',5000);`);
  old.close();
  const db = openDb(file);
  assert.equal(db.prepare('SELECT phone FROM students').get().phone, '20230001');
});

test('đổi mật khẩu: cần mật khẩu cũ, đăng xuất phiên khác, mật khẩu cũ hết hiệu lực', () => {
  const { db } = setup();
  const first = svc.register(db, { phone: '0911111111', name: 'Mai', password: 'matkhau1' });
  const other = svc.login(db, { username: '0911111111', password: 'matkhau1' });
  const user = { id: first.user.id, username: '0911111111' };
  assert.throws(() => svc.changePassword(db, user, { old_password: 'sai', new_password: 'matkhau2' }), { status: 401 });
  assert.throws(() => svc.changePassword(db, user, { old_password: 'matkhau1', new_password: '123' }), { status: 400 });
  assert.throws(() => svc.changePassword(db, user, { old_password: 'matkhau1', new_password: 'matkhau1' }), { status: 400 });
  const r = svc.changePassword(db, user, { old_password: 'matkhau1', new_password: 'matkhau2' });
  assert.ok(r.token);
  assert.equal(db.prepare('SELECT 1 FROM sessions WHERE token = ?').get(other.token), undefined);
  assert.throws(() => svc.login(db, { username: '0911111111', password: 'matkhau1' }), { status: 401 });
  assert.ok(svc.login(db, { username: '0911111111', password: 'matkhau2' }).token);
});

test('cấp lại mật khẩu cho sinh viên: chỉ với SV có thật, mật khẩu mới dùng được', () => {
  const { db } = setup();
  svc.register(db, { phone: '0922222222', name: 'Nam', password: 'matkhau1' });
  assert.throws(() => svc.resetStudentPassword(db, { phone: '0933333333', new_password: 'matkhau9' }), { status: 404 });
  assert.throws(() => svc.resetStudentPassword(db, { phone: 'tn', new_password: 'matkhau9' }), { status: 404 }); // không reset được tài khoản nhân viên
  assert.throws(() => svc.resetStudentPassword(db, { phone: '0922222222', new_password: '12' }), { status: 400 });
  assert.equal(svc.resetStudentPassword(db, { phone: '+84922222222', new_password: 'matkhau9' }).name, 'Nam');
  assert.throws(() => svc.login(db, { username: '0922222222', password: 'matkhau1' }), { status: 401 });
  assert.ok(svc.login(db, { username: '0922222222', password: 'matkhau9' }).token);
});
