# Căng tin HPUni

Ứng dụng web quản lý căng tin HPUni: bán hàng (tiền mặt / thẻ sinh viên), thực đơn & tồn kho,
thẻ sinh viên riêng tư với mã QR riêng, báo cáo theo ngày và theo tháng. Giao diện hồng pastel.

- **Công nghệ:** Node.js ≥ 22.13 (ESM), SQLite (`node:sqlite` tích hợp sẵn), HTML/CSS/JS thuần. Không có phụ thuộc chạy (runtime dependency).
- **Phân quyền:** `admin` (quản lý), `cashier` (thu ngân), `student` (sinh viên).

## Cài đặt & chạy
```bash
npm install                                        # chỉ cài công cụ dev (eslint, prettier)
npm run create-admin -- quanly matkhau123 "Quản lý" # tạo tài khoản quản lý đầu tiên (đăng nhập bằng tên này)
npm start                                          # http://localhost:3000
```
App khởi động **trống**, không có dữ liệu mẫu. Muốn demo/kiểm thử: `npm run seed`
(admin/admin123, thungan/thungan123 và 10 món; không có sinh viên mẫu, sinh viên tự đăng ký).

Docker: `docker compose up --build` (dữ liệu nằm trong volume `canteen-data`).

Biến môi trường: `PORT` (3000), `DB_FILE` (data/canteen.db), `TZ_OFFSET_MIN` (420 = UTC+7).

## Lệnh
| Lệnh | Việc |
|---|---|
| `npm test` | chạy kiểm thử tự động (node:test) |
| `npm run lint` / `format:check` | phân tích tĩnh / kiểm tra định dạng |
| `npm run build` | kiểm tra cú pháp và đóng gói vào `dist/` |

## Hướng dẫn sử dụng nhanh
1. **Quản lý:** tab *Thực đơn & kho* → thêm món, sửa giá/tồn kho; tab *Báo cáo* → xem ngày/tháng.
2. **Sinh viên:** *Đăng ký thẻ mới* (số điện thoại + họ tên + mật khẩu ≥ 6 ký tự) → nhận mã thẻ + QR riêng. Đăng nhập bằng số điện thoại + mật khẩu để xem số dư, lịch sử.
3. **Thu ngân:** tab *Bán hàng* → chọn món → *Tiền mặt*, hoặc *Thẻ sinh viên* (nhập mã thẻ dưới QR + mật khẩu sinh viên tự nhập). Nạp tiền thẻ ở ô *Nạp tiền vào thẻ*.

## Đổi / quên mật khẩu
- **Đổi mật khẩu:** mọi người dùng có tab *Đổi mật khẩu* (nhập mật khẩu cũ + mật khẩu mới); các phiên đăng nhập khác bị đăng xuất.
- **Sinh viên quên mật khẩu:** thu ngân/quản lý vào tab *Bán hàng* → *Cấp lại mật khẩu cho sinh viên* (SĐT + mật khẩu mới) sau khi xác minh trực tiếp. Chưa có OTP qua SMS vì cần nhà cung cấp SMS.
- **Nhân viên quên mật khẩu:** `npm run reset-password -- <tên đăng nhập> <mật khẩu mới>` (chạy trên máy chủ).

## Nâng cấp từ bản cũ (đăng nhập bằng MSSV)
CSDL cũ được tự động nâng cấp khi khởi động (cột `mssv` đổi thành `phone`). Tài khoản sinh viên cũ vẫn đăng nhập được bằng MSSV + PIN cũ; muốn dùng số điện thoại thì đăng ký thẻ mới.

## Cấu trúc
`src/` (server, services, auth, db) · `db/schema.sql` · `public/` (giao diện) · `scripts/` (seed, build, create-admin) · `test/` · `docs/chuong4.md` · `.github/workflows/ci.yml`
